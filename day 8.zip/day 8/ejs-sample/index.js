let express = require('express');
let app = express();
app.set('view engine','ejs');
app.get("/",function (req,res){
    res.render("wel",{name:'barath'});
});
app.listen(9000,function(req,res){
    console.log("server running in http://localhost:9000");
});
import http from "http";
import url from "url";
const server = http.createServer((req,res)=>
{
    res.writeHead(200,{'content-type':'Application/json'})
    res.end(JSON.stringify({
        data:"hello welcome sir",
        hr:"come on"
    }));
});
server.listen(5020,()=>{
    console.log("server is running in http://localhost:5020");
});
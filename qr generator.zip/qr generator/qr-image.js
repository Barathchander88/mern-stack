import qr from "qr-image";
import inquirer from "inquirer";
import fs from "fs";
import { error } from "console";
inquirer
    .prompt([
        {
            message:"please type the url",
            name:"URL",
        }
    ])
    .then((answers)=>
    {
        const url = answers.URL;
        console.log(url)
        var qrimage=qr.image(url,{type:"png"});
        qrimage.pipe(fs.createWriteStream("website_url.png"));
        fs.writeFile("URLText.txt",url,
    (error)=>
{
    if(error) throw error;
    console.log("file success");
});
// fs.close();
});
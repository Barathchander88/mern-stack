import http from "http";
import url from "url";

const server = http.createServer((req,res)=>
{
const parseUrl = url.parse(req.url, true);
if (parseUrl.pathname === "/" && req.method === "GET")
{
res.writeHead(200,{"content-type":"text/html"})
res.end("<h1>web server created successfully </h1>")
res.end("hi")
}
else if(parseUrl.pathname === "/about" && req.method === "GET")
{
    res.writeHead(200,{"content-type":"text/html"})
    res.end("<h2>about us<h2>")
}
});
server.listen(5020,()=>{
console.log("visit at http://localhost:5020");
});
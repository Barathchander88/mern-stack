const { error } = require("console");
const { errorMonitor } = require("events");
const fstream = require("fs");
fstream.writeFile("firstfile.txt","hello barath chander",(error)=>
{
    if (error) throw error;
    console.log("file successfully written")
},
fstream.readFile("firstfile.txt","utf-8",(error,data)=>
{
    if (error){
        console.log("error occured")

    };
    console.log(data)
})
);


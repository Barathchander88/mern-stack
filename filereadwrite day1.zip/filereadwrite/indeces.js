var generateName = require('sillyname');
var sillyName=generateName();
console.log(sillyName)
// import {generate,count} from "random-words";
// var generate = require("random-words");
// console.log(generate(5));
// import superheros from "superheroes"
// var superheroes = require("superheroes");
// const superherosName = superheroes.random();
// console.log(superherosName);
